var tiles = Resource.GetImage("map.png");

var part = tiles.Sprite(144, 361, 16, 31);
part.Origin(8, 15);
part.Position(45, 45);

var a = 0;

var map = Resource.GetMap(20, 15);
map.Cell(16, 16).Visible(14, 10);
map.SetSprite("a", tiles.Sprite(336, 400, 16, 16));
map.SetSprite("b", tiles.Sprite(400, 384, 16, 16));
map.Fill(-1);
map.Load(Resource.GetString("map.txt"));

var mouse = tiles.Sprite(504, 480, 16, 16);
mouse.Origin(8, 8);

var font = Resource.GetFont();

var effect = Resource.GetSound("boom.wav");

var states = System.GetStates();
if (states.length === 0) 
{
	var state = System.NewState();
	state.Set("Hello", "World");
	state.Save();
}
states = System.GetStates();

// var byteImage = Resource.GetImage([12, 23, 46, 34]);

function Loop() {
    map.Draw();

    a += 0.05;

    if (Input.ButtonUp(Buttons.MouseLeft)) 
	{
        effect.Play(false);
    }

    if (Input.ButtonDown(Buttons.MouseLeft)) 
	{
        map.Scroll(-1, 0);
    }

    if (Input.ButtonDown(Buttons.MouseRight)) 
	{
        map.Scroll(1, 0);
    }

    part.Rotation = a;
    part.Draw();

    var mp = Input.Mouse;

    mouse.Draw(mp.X, mp.Y);
		
	for (var i=0; i<states.length; i++) 
	{
		font.Draw(5, 5, 300, 100, states[i].Name);
	}
    // font.Draw(0, 0, 300, 100, map.GetPosition(Input.Mouse.X, Input.Mouse.Y));
    // font.Draw(0, 10, 300, 100, Input.Mouse);
	
	return ! Input.ButtonClick(Buttons.Back);
}